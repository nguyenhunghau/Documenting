package com.example.demodocker;

import com.example.service.PatientSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Admin
 */
@RestController
public class PatientController {
    
    @Autowired
    private PatientSerivce patientService;

    @GetMapping("/get-all")
    public ResponseEntity findAll() {
        return new ResponseEntity<>(patientService.findAll(), HttpStatus.OK);
    }
}
