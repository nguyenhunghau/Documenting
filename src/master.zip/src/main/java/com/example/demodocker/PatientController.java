package com.example.demodocker;

import com.example.entity.Patient;
import com.example.service.PatientSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Admin
 */
@RestController
public class PatientController {
    
    @Autowired
    private PatientSerivce patientService;

    @GetMapping("/get-all")
    public ResponseEntity findAll() {
        return new ResponseEntity<>(patientService.findAll(), HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity addNew(@RequestParam(value = "name") String name, @RequestParam(value = "dob") String dob, @RequestParam(value = "gender") String gender) throws ParseException {
        Patient patient = new Patient();
        patient.setName(name);
        SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-DD");
        patient.setDob(format.parse(dob));
        patient.setGender(gender);
        return new ResponseEntity<>(patientService.addNew(patient), HttpStatus.OK);
    }

    @PostMapping("/update")
    public ResponseEntity update(@RequestParam(value = "id") int id, @RequestParam(value = "name") String name, @RequestParam(value = "dob") String dob, @RequestParam(value = "gender") String gender) throws ParseException {
        Patient patient = new Patient();
        patient.setId(id);
        patient.setName(name);
        SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-DD");
        patient.setDob(format.parse(dob));
        patient.setGender(gender);
        return new ResponseEntity<>(patientService.update(patient), HttpStatus.OK);
    }

    @PostMapping("/delete")
    public ResponseEntity update(@RequestParam(value = "id") int id) {
        return new ResponseEntity<>(patientService.delete(id), HttpStatus.OK);
    }
}
