package com.example.service;

import com.example.entity.Patient;
import com.example.repository.PatientRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Admin
 */
@Service
public class PatientSerivce {
    
    @Autowired
    private PatientRepository patientRepo;
    
    public List<Patient> findAll() {
        return (List<Patient>)patientRepo.findAll();
    }

    public Patient addNew(Patient patient) {
        try {
            return patientRepo.save(patient);
        } catch (Exception ex) {
            return null;
        }
    }

    public Patient update(Patient patient) {
        try {
            Optional<Patient> old = patientRepo.findById(patient.getId());
            if(!old.isPresent()) {
                return null;
            }
            Patient oldPatient = old.get();
            oldPatient.setName(patient.getName());
            oldPatient.setGender(patient.getGender());
            oldPatient.setDob(patient.getDob());
            return patientRepo.save(oldPatient);
        } catch (Exception ex) {
            return null;
        }
    }

    public boolean delete(int id) {
        try {
            Optional<Patient> old = patientRepo.findById(id);
            if(!old.isPresent()) {
                return false;
            }
            patientRepo.delete(old.get());
            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
