package com.example.service;

import com.example.entity.Patient;
import com.example.repository.PatientRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Admin
 */
@Service
public class PatientSerivce {
    
    @Autowired
    private PatientRepository patientRepo;
    
    public List<Patient> findAll() {
        return (List<Patient>)patientRepo.findAll();
    }
}
