package com.example.repository;

import com.example.entity.Patient;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Admin
 */
@Repository
public interface PatientRepository extends CrudRepository<Patient, Integer>{
    
    
}
